import MySQLdb
import os
import string
import fileinput
import re

db = MySQLdb.connect (host="localhost",
    user="root",
    passwd="waf",
    db="waf",
    local_infile = 1) #Grants permission to write to db from an input file. Without this you get sql Error: (1148, 'The used command is not allowed with this MySQL version')

os.system("rm /tmp/*.csv") #menghapus semua file csv di tmp karena akan di update
os.system("rm kategori.csv severity.csv sumber.csv destination.csv") #menghapus semua file csv di log karena akan di update
#os.system("echo '' > /tmp/kategori.csv && echo '' > /tmp/severity.csv && echo '' > /tmp/sumber.csv && echo '' > /tmp/destination.csv")

print "\nConnection to DB established\n\n"

#The statement 'IGNORE 1 LINES' below makes the Python script ignore first line on csv file
#You can execute the sql below on the mysql bash to test if it works
sqlLoadData = """DELETE FROM tampilan;"""
print "berhasil mengahpus semua data		...ok"

sqlLoadData2 = """load data local infile '/var/log/apache2/clean.csv' into table tampilan FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES;"""
print "berhasil import csv			...ok"

sqlLoadData3 = """DELETE FROM tampilan WHERE kategori = '';""" #menghapus data yg rumpang
print "berhasil drop semua row yang rumpang	...ok"

sqlLoadData4 = """SELECT kategori,count(kategori) FROM tampilan GROUP BY kategori INTO OUTFILE '/tmp/kategori.csv';"""
print "berhasil get kategori			...ok"

sqlLoadData5 = """SELECT severity,count(severity) FROM tampilan GROUP BY severity INTO OUTFILE '/tmp/severity.csv';"""
print "berhasil get severity                    ...ok"

sqlLoadData6 = """SELECT sumber,count(sumber) FROM tampilan GROUP BY sumber INTO OUTFILE '/tmp/sumber.csv';"""
print "berhasil get sumber                      ...ok"

sqlLoadData7 = """SELECT destination,count(destination) FROM tampilan GROUP BY destination INTO OUTFILE '/tmp/destination.csv';"""
print "berhasil get destination                 ...ok"

curs = db.cursor()
curs.execute(sqlLoadData)
curs.execute(sqlLoadData2)
curs.execute(sqlLoadData3)
curs.execute(sqlLoadData4)
curs.execute(sqlLoadData5)
curs.execute(sqlLoadData6)
curs.execute(sqlLoadData7)
db.commit()

os.system("mv /tmp/*.csv /var/log/apache2/")


#menambahkan *variable,jumlah pada baris pertama sebagai format csv

#======> csv kategori
with open("kategori.csv") as f:
        newText = f.read()
        newText = re.sub('\t', ',', newText)
        with open("kategori.csv", "w") as f:
                f.write(newText)
for line in fileinput.input(files=['kategori.csv'], inplace=True):
    if fileinput.isfirstline():
        print 'kategori,jumlah'
    print line,
#memasukkan csv kategori ke mysql
sqlLoadData8 = """DELETE FROM kategori;"""
sqlLoadData9 = """load data local infile '/var/log/apache2/kategori.csv' into table kategori FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES;"""

#======> csv severity
with open("severity.csv") as f:
        newText = f.read()
        newText = re.sub('\t', ',', newText)
        with open("severity.csv", "w") as f:
                f.write(newText)
for line in fileinput.input(files=['severity.csv'], inplace=True):
    if fileinput.isfirstline():
        print 'severity,jumlah'
    print line,
#memasukkan csv severity ke mysql
sqlLoadData10 = """DELETE FROM severity;"""
sqlLoadData11 = """load data local infile '/var/log/apache2/severity.csv' into table severity FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES;"""

#======> csv sumber
with open("sumber.csv") as f:
        newText = f.read()
        newText = re.sub('\t', ',', newText)
        with open("sumber.csv", "w") as f:
                f.write(newText)
for line in fileinput.input(files=['sumber.csv'], inplace=True):
    if fileinput.isfirstline():
        print 'sumber,jumlah'
    print line,
#memasukkan csv sumber ke mysql
sqlLoadData12 = """DELETE FROM sumber;"""
sqlLoadData13 = """load data local infile '/var/log/apache2/sumber.csv' into table sumber FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES;"""

#======> csv destination
with open("destination.csv") as f:
        newText = f.read()
        newText = re.sub('\t', ',', newText)
        with open("destination.csv", "w") as f:
                f.write(newText)
for line in fileinput.input(files=['destination.csv'], inplace=True):
    if fileinput.isfirstline():
        print 'destination,jumlah'
    print line,
#memasukkan csv destination ke mysql
sqlLoadData14 = """DELETE FROM destination;"""
sqlLoadData15 = """load data local infile '/var/log/apache2/destination.csv' into table destination FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES;"""

curs.execute(sqlLoadData8)
curs.execute(sqlLoadData9)
curs.execute(sqlLoadData10)
curs.execute(sqlLoadData11)
curs.execute(sqlLoadData12)
curs.execute(sqlLoadData13)
curs.execute(sqlLoadData14)
curs.execute(sqlLoadData15)
db.commit()

db.close()
print "\nData loading complete.\n"
