import re
import fileinput

f=open('error.log','r')
input_stream=f.read()
output_stream=""
input_stream_lines=input_stream.split("\n")
for line in input_stream_lines:
    if "client" not in line or "msg" not in line or "OWASP_TOP_" not in line:
            pass
    else:
            output_stream=output_stream+line+"\n"
    g=open('clean.csv','w')
    g.write(output_stream)

with open("clean.csv") as f:
        newText = f.read()
	newText = re.sub(r"\].*?\[", "] [", newText)
	newText = re.sub(r' +', " ", newText)
	newText = re.sub(r"\[:error\]", "", newText)
	newText = re.sub(r"\[pid.*?\]", "", newText)
	newText = re.sub(r"\[file.*?\]", "", newText)
	newText = re.sub(r"\[\\\\.*?\[line", "[line", newText)
	newText = re.sub(r"\[\).*?\[line", "[line", newText)
	newText = re.sub(r"\[\#.*?\[line", "[line", newText)
	newText = re.sub(r"\[line.*?\[id", "[id", newText)
	newText = re.sub(r"\[id.*?\[msg", "[msg", newText)
	newText = re.sub(r"\[data.*?\]", "", newText)
	newText = re.sub(r'\[ver "OWASP_CRS.*?\]', '', newText)
	newText = re.sub(r'\[tag "app.*?\]', '', newText)
	newText = re.sub(r'\[tag "lan.*?\]', '', newText)
	newText = re.sub(r'\[tag "pla.*?\]', '', newText)
	newText = re.sub(r'\[tag "att.*?\]', '', newText)
	newText = re.sub(r'\[tag "OWASP_CRS.*?\]', '', newText)
	newText = re.sub(r'\[tag "WASC.*?\]', '', newText)
	newText = re.sub(r'\[tag "PCI.*?\]', '', newText)
	newText = re.sub(r'\[tag "OWASP_App.*?\]', '', newText)
	newText = re.sub(r'\[uniq.*?\]', '', newText)
	newText = re.sub(r' +', " ", newText)
	newText = re.sub(r'\] \[', ',', newText)
	newText = re.sub(r'client', '', newText)
	newText = re.sub(r'msg', '', newText)
	newText = re.sub(r'severity', '', newText)
	newText = re.sub(r'tag', '', newText)
	newText = re.sub(r'hostname', '', newText)
	newText = re.sub(r'uri', '', newText)
	newText = re.sub(r'"', '', newText)
	newText = re.sub(r'\[', '', newText)
	newText = re.sub(r'\]', '', newText)
	newText = re.sub(r'\, waitfor.*? attempts', '', newText)
	newText = re.sub(r'\, ora.*?rs.', '', newText)
	newText = re.sub(r'PCI\/6.5.\S+', '', newText)
	newText = re.sub(r'ta', '', newText)
        with open("clean.csv", "w") as f:
                f.write(newText)

for line in fileinput.input(files=['clean.csv'], inplace=True):
    if fileinput.isfirstline():
        print 'tanggal,sumber,pesan,severity,kategori,destination,uri'
    print line,

