<?php

//PUT THIS HEADER ON TOP OF EACH UNIQUE PAGE
session_start();
if (!isset($_SESSION['username'])) {
    header("location:login/main_login.php");
}

$koneksi     		= mysqli_connect("localhost", "root", "waf", "waf");

$kategori    		= mysqli_query($koneksi, "SELECT kategori FROM kategori");
$jumlahkategori		= mysqli_query($koneksi, "SELECT jumlah FROM kategori");

$severity               = mysqli_query($koneksi, "SELECT severity FROM severity");
$jumlahseverity         = mysqli_query($koneksi, "SELECT jumlah FROM severity");

$sumber                 = mysqli_query($koneksi, "SELECT sumber FROM sumber");
$jumlahsumber           = mysqli_query($koneksi, "SELECT jumlah FROM sumber");

$destination            = mysqli_query($koneksi, "SELECT destination FROM destination");
$jumlahdestination      = mysqli_query($koneksi, "SELECT jumlah FROM destination");

shell_exec("cd /var/log/apache2/ && python /var/log/apache2/clean3.py");
shell_exec("cd /var/log/apache2/ && python /var/log/apache2/databseimport2.py");

?>
<html>
    <head>
        <title>WAF BSSN</title>
        <script src="chartjs/Chart.bundle.js"></script>
	<meta http-equiv="refresh" content="5; url="<?php echo $_SERVER['PHP_SELF']; ?>">
        <style type="text/css">
        .container {
        	width: 50%;
                margin: 50px auto;
        }

	* {
 		box-sizing: border-box;
	}

	/* Create two equal columns that floats next to each other */
	.column {
		float: left;
		width: 40%;
		padding: 10px;
		height: 300px; /* Should be removed. Only for demonstration */
	}

	/* Clear floats after the columns */
	.row:after {
		  content: "";
		  display: table;
		  clear: both;
	}

	.wrapper {
	          height: 350px !important;
	}

	/* untuk side menu */
	body {
	  font-family: "Lato", sans-serif;
	}

	.sidenav {
	  height: 100%;
	  width: 13%;
	  position: fixed;
	  z-index: 1;
	  top: 0;
	  left: 0;
	  background-color: #111;
	  overflow-x: hidden;
	  padding-top: 20px;
	}

	.sidenav a {
	  padding: 6px 6px 6px 32px;
	  text-decoration: none;
	  font-size: 25px;
	  color: #818181;
	  display: block;
	}

	.sidenav a:hover {
	  color: #f1f1f1;
	}

	.main {
	  margin-left: 250px; /* Same as the width of the sidenav */
	}

	@media screen and (max-height: 450px) {
	  .sidenav {padding-top: 15px;}
	  .sidenav a {font-size: 18px;}
	}

	img {
 	   width: 80%;
	}

        </style>
    </head>
    <body>

<div class="sidenav">
  <img src="img/LOGO_BSSN.png" alt="BSSN" style="padding-left:20px; padding-bottom:20px">
  <a href="#">Dashboard</a>
  <a href="log/index.php">Log Serangan</a>
  <a href="ApacheConf/index.html">Konfigurasi</a>
  <a href="login/logout.php">Logout</a>
</div>

<div class="main">

   <div class="row">

	<div class="column">
        <div class="container">
	    <p>kategori OWASP</p>
            <canvas id="myChart" width="100" height="100"></canvas>
        </div>
        <script>
            var ctx = document.getElementById("myChart");
            var myChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: [<?php while ($b = mysqli_fetch_array($kategori)) { echo '"' . $b['kategori'] . '",';}?>],
                    datasets: [{
                            label: 'jumlah',
                            data: [<?php while ($p = mysqli_fetch_array($jumlahkategori)) { echo '"' . $p['jumlah'] . '",';}?>],
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)',
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)'
                            ],
                            borderColor: [
                                'rgba(255,99,132,1)',
                                'rgba(54, 162, 235, 1)',
                                'rgba(255, 206, 86, 1)',
                                'rgba(75, 192, 192, 1)',
                                'rgba(153, 102, 255, 1)',
                                'rgba(255, 159, 64, 1)',
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)'
                            ],
                            borderWidth: 1
                        }]
                },
                options: {
                }
            });
        </script>

        <div class="container">
            <p>sumber serangan</p>
            <canvas id="myChart3" width="100" height="100"></canvas>
        </div>
        <script>
            var ctx = document.getElementById("myChart3");
            var myChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: [<?php while ($b = mysqli_fetch_array($sumber)) { echo '"' . $b['sumber'] . '",';}?>],
                    datasets: [{
                            label: 'jumlah',
                            data: [<?php while ($p = mysqli_fetch_array($jumlahsumber)) { echo '"' . $p['jumlah'] . '",';}?>],
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)',
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)'
                            ],
                            borderColor: [
                                'rgba(255,99,132,1)',
                                'rgba(54, 162, 235, 1)',
                                'rgba(255, 206, 86, 1)',
                                'rgba(75, 192, 192, 1)',
                                'rgba(153, 102, 255, 1)',
                                'rgba(255, 159, 64, 1)',
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)'
                            ],
                            borderWidth: 1
                        }]
                },
                options: {
                    scales: {
                        yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                    }
                }
            });
        </script>
	</div>
	<div class="column">
	<div class="container">
            <p>tingkat severity</p>
            <canvas id="myChart2" width="100" height="100"></canvas>
        </div>
        <script>
            var ctx = document.getElementById("myChart2");
            var myChart2 = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: [<?php while ($b = mysqli_fetch_array($severity)) { echo '"' . $b['severity'] . '",';}?>],
                    datasets: [{
                            label: 'jumlah',
                            data: [<?php while ($p = mysqli_fetch_array($jumlahseverity)) { echo '"' . $p['jumlah'] . '",';}?>],
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)',
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)'
                            ],
                            borderColor: [
                                'rgba(255,99,132,1)',
                                'rgba(54, 162, 235, 1)',
                                'rgba(255, 206, 86, 1)',
                                'rgba(75, 192, 192, 1)',
                                'rgba(153, 102, 255, 1)',
                                'rgba(255, 159, 64, 1)',
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)'
                            ],
                            borderWidth: 1
                        }]
                },
                options: {
                }
            });
        </script>
        <div class="container">
            <p>destination</p>
            <canvas id="myChart4" width="100" height="100"></canvas>
        </div>
        <script>
            var ctx = document.getElementById("myChart4");
            var myChart4 = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: [<?php while ($b = mysqli_fetch_array($destination)) { echo '"' . $b['destination'] . '",';}?>],
                    datasets: [{
                            label: 'jumlah',
                            data: [<?php while ($p = mysqli_fetch_array($jumlahdestination)) { echo '"' . $p['jumlah'] . '",';}?>],
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)',
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)'
                            ],
                            borderColor: [
                                'rgba(255,99,132,1)',
                                'rgba(54, 162, 235, 1)',
                                'rgba(255, 206, 86, 1)',
                                'rgba(75, 192, 192, 1)',
                                'rgba(153, 102, 255, 1)',
                                'rgba(255, 159, 64, 1)',
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)'
                            ],
                            borderWidth: 1
                        }]
                },
                options: {
                    scales: {
                        yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                    }
                }
            });
        </script>

	</div>

      </div>
    </div>
    </body>
</html>
