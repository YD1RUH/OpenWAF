<?php
//PUT THIS HEADER ON TOP OF EACH UNIQUE PAGE
session_start();
if (!isset($_SESSION['username'])) {
    header("location:../login/main_login.php");
}

 $path = 'data.txt';
 shell_exec("rm data.txt");
 if (isset($_POST['ProxyPassReverse']) && isset($_POST['ProxyPass']) && isset($_POST['DocumentRoot']) && isset($_POST['ServerAdmin']) && isset($_POST['ServerName'])) {
    $fh = fopen($path,"a+");
    $string = 
	'<VirtualHost *:80>'."\n".
	'#ServerName '.$_POST['ServerName']."\n".
	'	Timeout 2400'."\n".
	'	ProxyTimeout 2400'."\n".
	'	ProxyBadHeader ignore'."\n".
	'	ServerName '.$_POST['ServerName']."\n".
	'	ServerAdmin '.$_POST['ServerAdmin']."\n".
	'	DocumentRoot '.$_POST['DocumentRoot']."\n".
	'	ProxyRequests off'."\n".
	'	ProxyPreserveHost On'."\n".
	'	ProxyPass '.'/'.'audit '.'!'."\n".
	'	ProxyPass '.'/'.' http'.':'.'/'.'/'.$_POST['ProxyPass'].'/'."\n".
	'	ProxyPassReverse '.'/'.' http'.':'.'/'.'/'.$_POST['ProxyPassReverse'].'/'."\n".
	'# allow from everywhere'."\n".
	'	#<Proxy *>'."\n".
	'	#	Order deny,allow'."\n".
	'	#	Allow from all'."\n".
	'	#</Proxy>'."\n"."\n".
	'	ErrorLog ${APACHE_LOG_DIR}/error.log'."\n".
	'	CustomLog ${APACHE_LOG_DIR}/access.log combined'."\n".
	'</VirtualHost>';
    fwrite($fh,$string); // Write information to the file
    fclose($fh); // Close the file
    shell_exec("cp data.txt /etc/apache2/initest.conf");
 }

 if(!empty($_POST['badrobots'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_35_bad_robots.data.deactive /etc/modsecurity/base_rules/modsecurity_35_bad_robots.data");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_35_bad_robots.data /etc/modsecurity/base_rules/modsecurity_35_bad_robots.data.deactive");
 }

 if(!empty($_POST['scanners'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_35_scanners.data.deactive /etc/modsecurity/base_rules/modsecurity_35_scanners.data");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_35_scanners.data /etc/modsecurity/base_rules/modsecurity_35_scanners.data.deactive");
 }

 if(!empty($_POST['sqlinjectionattacks'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_41_sql_injection_attacks.data.deactive /etc/modsecurity/base_rules/modsecurity_41_sql_injection_attacks.data");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_41_sql_injection_attacks.data /etc/modsecurity/base_rules/modsecurity_41_sql_injection_attacks.data.deactive");
 }

 if(!empty($_POST['outbond'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_50_outbound.data.deactive /etc/modsecurity/base_rules/modsecurity_50_outbound.data");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_50_outbound.data /etc/modsecurity/base_rules/modsecurity_50_outbound.data.deactive");
 }

 if(!empty($_POST['outbondmalware'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_50_outbound_malware.data.deactive /etc/modsecurity/base_rules/modsecurity_50_outbound_malware.data");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_50_outbound_malware.data /etc/modsecurity/base_rules/modsecurity_50_outbound_malware.data.deactive");
 }

 if(!empty($_POST['CRSprotocolviolations'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_20_protocol_violations.conf.deactive /etc/modsecurity/base_rules/modsecurity_crs_20_protocol_violations.conf");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_20_protocol_violations.conf /etc/modsecurity/base_rules/modsecurity_crs_20_protocol_violations.conf.deactive");
 }

 if(!empty($_POST['CRSprotocolanomalies'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_21_protocol_anomalies.conf.deactive /etc/modsecurity/base_rules/modsecurity_crs_21_protocol_anomalies.conf");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_21_protocol_anomalies.conf /etc/modsecurity/base_rules/modsecurity_crs_21_protocol_anomalies.conf.deactive");
 }

 if(!empty($_POST['CRSrequestlimits'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_23_request_limits.conf.deactive /etc/modsecurity/base_rules/modsecurity_crs_23_request_limits.conf");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_23_request_limits.conf /etc/modsecurity/base_rules/modsecurity_crs_23_request_limits.conf.deactive");
 }

 if(!empty($_POST['CRShttppolicy'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_30_http_policy.conf.deactive /etc/modsecurity/base_rules/modsecurity_crs_30_http_policy.conf");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_30_http_policy.conf /etc/modsecurity/base_rules/modsecurity_crs_30_http_policy.conf.deactive");
 }

 if(!empty($_POST['CRSbadrobots'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_35_bad_robots.conf.deactive /etc/modsecurity/base_rules/modsecurity_crs_35_bad_robots.conf");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_35_bad_robots.conf /etc/modsecurity/base_rules/modsecurity_crs_35_bad_robots.conf.deactive");
 }

 if(!empty($_POST['CRSgenericattacks'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_40_generic_attacks.conf.deactive /etc/modsecurity/base_rules/modsecurity_crs_40_generic_attacks.conf");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_40_generic_attacks.conf /etc/modsecurity/base_rules/modsecurity_crs_40_generic_attacks.conf.deactive");
 }

 if(!empty($_POST['CRSsqlinjectionattacks'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_41_sql_injection_attacks.conf.deactive /etc/modsecurity/base_rules/modsecurity_crs_41_sql_injection_attacks.conf");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_41_sql_injection_attacks.conf /etc/modsecurity/base_rules/modsecurity_crs_41_sql_injection_attacks.conf.deactive");
 }

 if(!empty($_POST['CRSxssattacks'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_41_xss_attacks.conf.deactive /etc/modsecurity/base_rules/modsecurity_crs_41_xss_attacks.conf");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_41_xss_attacks.conf /etc/modsecurity/base_rules/modsecurity_crs_41_xss_attacks.conf.deactive");
 }

 if(!empty($_POST['CRStightsecurity'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_42_tight_security.conf.deactive /etc/modsecurity/base_rules/modsecurity_crs_42_tight_security.conf");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_42_tight_security.conf /etc/modsecurity/base_rules/modsecurity_crs_42_tight_security.conf.deactive");
 }

 if(!empty($_POST['CRStrojans'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_45_trojans.conf.deactive /etc/modsecurity/base_rules/modsecurity_crs_45_trojans.conf");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_45_trojans.conf /etc/modsecurity/base_rules/modsecurity_crs_45_trojans.conf.deactive");
 }

 if(!empty($_POST['CRScommonexceptions'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_47_common_exceptions.conf.deactive /etc/modsecurity/base_rules/modsecurity_crs_47_common_exceptions.conf");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_47_common_exceptions.conf /etc/modsecurity/base_rules/modsecurity_crs_47_common_exceptions.conf.deactive");
 }

 if(!empty($_POST['CRSlocalexceptions'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_48_local_exceptions.conf.example.deactive /etc/modsecurity/base_rules/modsecurity_crs_48_local_exceptions.conf.example");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_48_local_exceptions.conf.example /etc/modsecurity/base_rules/modsecurity_crs_48_local_exceptions.conf.example.deactive");
 }

 if(!empty($_POST['CRSinboundblocking'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_49_inbound_blocking.conf.deactive /etc/modsecurity/base_rules/modsecurity_crs_49_inbound_blocking.conf");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_49_inbound_blocking.conf /etc/modsecurity/base_rules/modsecurity_crs_49_inbound_blocking.conf.deactive");
 }

 if(!empty($_POST['CRSoutbond'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_50_outbound.conf.deactive /etc/modsecurity/base_rules/modsecurity_crs_50_outbound.conf");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_50_outbound.conf /etc/modsecurity/base_rules/modsecurity_crs_50_outbound.conf.deactive");
 }

 if(!empty($_POST['CRSoutboundblocking'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_59_outbound_blocking.conf.deactive /etc/modsecurity/base_rules/modsecurity_crs_59_outbound_blocking.conf");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_59_outbound_blocking.conf /etc/modsecurity/base_rules/modsecurity_crs_59_outbound_blocking.conf.deactive");
 }

 if(!empty($_POST['CRScorrelation'])) {
    // jika di ceklis
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_60_correlation.conf.deactive /etc/modsecurity/base_rules/modsecurity_crs_60_correlation.conf");
 } else {
    // user did not check the box
    shell_exec("mv /etc/modsecurity/base_rules/modsecurity_crs_60_correlation.conf /etc/modsecurity/base_rules/modsecurity_crs_60_correlation.conf.deactive");
 }

?>
<h2>Pengaturan Berhasil Tersimpan</h2>
<input type="button" value="Halaman Utama" onclick="window.location.href='../index2.php'" />
<?php

?>
