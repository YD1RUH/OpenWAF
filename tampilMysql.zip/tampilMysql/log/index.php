<?php
//PUT THIS HEADER ON TOP OF EACH UNIQUE PAGE
session_start();
if (!isset($_SESSION['username'])) {
    header("location:../login/main_login.php");
}
?>

<html>
<head>
<title>Log serangan WAF</title>
<link rel="stylesheet" href="css/bootstrap.min.css">

<style>
body {
          font-family: "Lato", sans-serif;
        }

        .sidenav {
          height: 100%;
          width: 13%;
          position: fixed;
          z-index: 1;
          top: 0;
          left: 0;
          background-color: #111;
          overflow-x: hidden;
          padding-top: 20px;
        }

        .sidenav a {
          padding: 6px 6px 6px 32px;
          text-decoration: none;
          font-size: 25px;
          color: #818181;
          display: block;
        }

        .sidenav a:hover {
          color: #f1f1f1;
        }

        .main {
          margin-left: 250px; /* Same as the width of the sidenav */
        }

        @media screen and (max-height: 450px) {
          .sidenav {padding-top: 15px;}
          .sidenav a {font-size: 18px;}
        }

        img {
           width: 80%;
        }
</style>

</head>
<body>

<div class="sidenav">
  <img src="img/LOGO_BSSN.png" alt="BSSN" style="padding-left:20px; padding-bottom:20px">
  <a href="../index.php">Dashboard</a>
  <a href="#">Log Serangan</a>
  <a href="../ApacheConf/index.html">Konfigurasi</a>
  <a href="../login/logout.php">Logout</a>
</div>

<div class="main">

<div style="width:1000px; margin:0 auto;">

<h3>Log serangan WAF</h3>
<table class="table table-striped table-bordered">
<thead>
<tr>
<th style='width:150px;'>tanggal</th>
<th style='width:150px;'>sumber</th>
<th style='width:150px;'>pesan</th>
<th style='width:150px;'>severity</th>
<th style='width:150px;'>kategori</th>
<th style='width:150px;'>destination</th>
<th style='width:150px;'>uri</th>
</tr>
</thead>
<tbody>
<?php
include('db.php');

if (isset($_GET['page_no']) && $_GET['page_no']!="") {
	$page_no = $_GET['page_no'];
	} else {
		$page_no = 1;
        }

	$total_records_per_page = 5;
    $offset = ($page_no-1) * $total_records_per_page;
	$previous_page = $page_no - 1;
	$next_page = $page_no + 1;
	$adjacents = "2";

	$result_count = mysqli_query($con,"SELECT COUNT(*) As total_records FROM `tampilan`");
	$total_records = mysqli_fetch_array($result_count);
	//$total_records = mysqli_free_result($result_count);
	//$total_records = (isset($_GET['total_records'])) ? (int)$_GET['total_records'] : 0;
    	$total_records = $total_records['total_records'];
	$total_no_of_pages = ceil($total_records / $total_records_per_page);
	$second_last = $total_no_of_pages - 1; // total page minus 1

    $result = mysqli_query($con,"SELECT * FROM `tampilan` LIMIT $offset, $total_records_per_page");
    //$result = mysqli_query($con,"SELECT * FROM `tampilan` LIMIT 10");
    while($row = mysqli_fetch_array($result)){
		echo "<tr>
			  <td>".$row['tanggal']."</td>
			  <td>".$row['sumber']."</td>
	 		  <td>".$row['pesan']."</td>
		   	  <td>".$row['severity']."</td>
			  <td>".$row['kategori']."</td>
			  <td>".$row['destination']."</td>
			  <td>".$row['uri']."</td>
		   	  </tr>";
        }
	mysqli_close($con);
    ?>
</tbody>
</table>

<div style='padding: 10px 20px 0px; border-top: dotted 1px #CCC;'>
<strong>Page <?php echo $page_no." of ".$total_no_of_pages; ?></strong>
</div>

<ul class="pagination">
	<?php  //if($page_no > 1){ echo "<li><a href='?page_no=1'>First Page</a></li>"; } ?>
    
	<li <?php if($page_no <= 1){ echo "class='disabled'"; } ?>>
	<a <?php if($page_no > 1){ echo "href='?page_no=$previous_page'"; } ?>>Previous</a>
	</li>
       
    <?php 
	if ($total_no_of_pages <= 10){  	 
		for ($counter = 1; $counter <= $total_no_of_pages; $counter++){
			if ($counter == $page_no) {
		   echo "<li class='active'><a>$counter</a></li>";	
				}else{
           echo "<li><a href='?page_no=$counter'>$counter</a></li>";
				}
        }
	}
	elseif($total_no_of_pages > 10){
		
	if($page_no <= 4) {			
	 for ($counter = 1; $counter < 8; $counter++){		 
			if ($counter == $page_no) {
		   echo "<li class='active'><a>$counter</a></li>";	
				}else{
           echo "<li><a href='?page_no=$counter'>$counter</a></li>";
				}
        }
		echo "<li><a>...</a></li>";
		echo "<li><a href='?page_no=$second_last'>$second_last</a></li>";
		echo "<li><a href='?page_no=$total_no_of_pages'>$total_no_of_pages</a></li>";
		}

	 elseif($page_no > 4 && $page_no < $total_no_of_pages - 4) {		 
		echo "<li><a href='?page_no=1'>1</a></li>";
		echo "<li><a href='?page_no=2'>2</a></li>";
        echo "<li><a>...</a></li>";
        for ($counter = $page_no - $adjacents; $counter <= $page_no + $adjacents; $counter++) {			
           if ($counter == $page_no) {
		   echo "<li class='active'><a>$counter</a></li>";	
				}else{
           echo "<li><a href='?page_no=$counter'>$counter</a></li>";
				}                  
       }
       echo "<li><a>...</a></li>";
	   echo "<li><a href='?page_no=$second_last'>$second_last</a></li>";
	   echo "<li><a href='?page_no=$total_no_of_pages'>$total_no_of_pages</a></li>";      
            }
		
		else {
        echo "<li><a href='?page_no=1'>1</a></li>";
		echo "<li><a href='?page_no=2'>2</a></li>";
        echo "<li><a>...</a></li>";

        for ($counter = $total_no_of_pages - 6; $counter <= $total_no_of_pages; $counter++) {
          if ($counter == $page_no) {
		   echo "<li class='active'><a>$counter</a></li>";	
				}else{
           echo "<li><a href='?page_no=$counter'>$counter</a></li>";
				}                   
                }
            }
	}
?>
    
	<li <?php if($page_no >= $total_no_of_pages){ echo "class='disabled'"; } ?>>
	<a <?php if($page_no < $total_no_of_pages) { echo "href='?page_no=$next_page'"; } ?>>Next</a>
	</li>
    <?php if($page_no < $total_no_of_pages){
		echo "<li><a href='?page_no=$total_no_of_pages'>Last &rsaquo;&rsaquo;</a></li>";
		} ?>
</ul>
</div>
</div>
</body>
</html>
